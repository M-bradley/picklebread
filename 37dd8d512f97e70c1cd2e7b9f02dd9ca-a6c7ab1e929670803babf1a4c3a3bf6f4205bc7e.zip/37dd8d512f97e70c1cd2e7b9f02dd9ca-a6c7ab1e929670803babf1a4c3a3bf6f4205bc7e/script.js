// Some assembly required, batteries sold separately

// Inspiration
// https://www.pinterest.com/pin/556687203921295406/